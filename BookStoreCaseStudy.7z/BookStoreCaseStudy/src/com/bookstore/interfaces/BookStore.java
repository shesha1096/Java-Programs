package com.bookstore.interfaces;

import com.bookstore.model.Book;

public interface BookStore {
	public void addBook(Book book);
	public void removeBook(Book book);

}
