package com.dao.interfaces;

import com.classes.Book;

public interface BookStore {
	public void addBook(Book book);
	public void removeBook(Book book);

}
